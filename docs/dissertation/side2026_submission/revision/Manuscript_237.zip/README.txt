Paper 237, SIDe 2026 -- revised manuscript (LaTeX, IEEE conference template)

Manuscript_237_highlighted.pdf  the revised paper with changes marked: text added or
                                changed since the submitted version is blue; Tables II
                                and III (new / rewritten) are blue throughout; all three
                                figures are new or redrawn.
Manuscript_237_clean.pdf        the same revision without markup.
main.tex                        LaTeX source of the clean revision (anonymised).
main_highlighted.tex            LaTeX source of the marked copy (latexdiff, additions only).
figures/                        the three figures as PDF.
IEEEtran.cls                    the class file from the IEEE conference template
                                (conference-latex-template_10-17-19, V1.8b).

Both sources compile with:  latexmk -pdf main.tex
